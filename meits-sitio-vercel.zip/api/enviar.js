// Recibe el formulario de contacto y lo envía por correo (Vercel).
// Variables de entorno en Vercel (Settings > Environment Variables):
//   SMTP_USER = hola@meits.com.mx      (buzón desde donde se envía)
//   SMTP_PASS = contraseña de ese buzón
//   SMTP_HOST = smtp.hostinger.com     (opcional; valor por defecto)
//   SMTP_PORT = 465                    (opcional; valor por defecto)
//   MAIL_TO   = hola@meits.com.mx      (opcional; quién recibe los mensajes)
const nodemailer = require("nodemailer");

module.exports = async (req, res) => {
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  res.setHeader("Cache-Control", "no-store");
  if (req.method !== "POST") return res.status(405).json({ ok: false, error: "metodo" });

  let b = req.body;
  if (typeof b === "string") { try { b = JSON.parse(b); } catch (e) { b = {}; } }
  b = b || {};

  if (b.web) return res.status(200).json({ ok: true }); // trampa anti-spam

  const lim = (v, m) => String(v || "").replace(/[\r\0]/g, "").trim().slice(0, m);
  const nombre = lim(b.nombre, 120), empresa = lim(b.empresa, 120), contacto = lim(b.contacto, 160);
  const temas = lim(b.temas, 300), mensaje = lim(b.mensaje, 4000);
  if (!contacto || (!mensaje && !temas)) return res.status(422).json({ ok: false, error: "datos" });

  const { SMTP_HOST = "smtp.hostinger.com", SMTP_PORT = "465", SMTP_USER, SMTP_PASS, MAIL_TO = "hola@meits.com.mx" } = process.env;
  if (!SMTP_USER || !SMTP_PASS) return res.status(500).json({ ok: false, error: "sin_configurar" });

  try {
    const transporte = nodemailer.createTransport({
      host: SMTP_HOST,
      port: Number(SMTP_PORT),
      secure: Number(SMTP_PORT) === 465,
      auth: { user: SMTP_USER, pass: SMTP_PASS },
    });
    await transporte.sendMail({
      from: `"Meits Web" <${SMTP_USER}>`,
      to: MAIL_TO,
      replyTo: /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(contacto) ? contacto : undefined,
      subject: "Contacto desde la web de Meits",
      text: `Nombre: ${nombre}\nEmpresa: ${empresa}\nContacto: ${contacto}\nLe interesa: ${temas}\n\nMensaje:\n${mensaje}\n`,
    });
    return res.status(200).json({ ok: true });
  } catch (e) {
    return res.status(500).json({ ok: false, error: "envio_fallido" });
  }
};
